#ifndef _TEMP_CODE_H_
#define _TEMP_CODE_H_

#include<fstream>

using namespace std;

class TempCode
{
private:
	ofstream tempCode;

};

#endif // _TEMP_CODE_H_
